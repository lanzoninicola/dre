import { Form } from "@remix-run/react";

// Modal para mover conta entre grupos
export default function MoveAccountModal({ account, dreGroups, onClose }) {
  const filteredGroups = dreGroups.filter(g =>
    g.type === account.type && g.id !== account.dreGroup.id
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">
            Mover Conta: {account.name}
          </h3>
          <p className="text-sm text-gray-500 mt-1">
            Grupo atual: {account.dreGroup.name}
          </p>
        </div>

        <Form method="post" className="p-6">
          <input type="hidden" name="intent" value="move" />
          <input type="hidden" name="accountId" value={account.id} />

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Novo Grupo DRE
            </label>
            <select
              name="newDreGroupId"
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
              required
            >
              <option value="">Selecione um grupo</option>
              {filteredGroups.map(group => (
                <option key={group.id} value={group.id}>
                  {group.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="btn-secondary flex-1"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="btn-primary flex-1"
              disabled={filteredGroups.length === 0}
            >
              Mover
            </button>
          </div>
        </Form>
      </div>
    </div>
  );
}