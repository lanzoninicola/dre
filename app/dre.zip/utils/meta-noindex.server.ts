export default function metaNoIndex() {
  return {
    name: "robots",
    content: "noindex",
  };
}
