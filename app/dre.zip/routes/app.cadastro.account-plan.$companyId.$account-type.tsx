import { Outlet } from "@remix-run/react";
import { randomInt } from "crypto";
import { LoaderFunction } from "react-router";
import { requireUser } from "~/domain/auth/auth.server";

export const loader: LoaderFunction = async ({ request }) => {
  const user = await requireUser(request);

  return null
}



export default function AccountPlanCompanyIdType() {

  return (
    <>
      <div>hwllo</div>
      <Outlet key={randomInt(99)} />
    </>
  )
}