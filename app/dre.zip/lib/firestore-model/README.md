# firestore-model

Status: WIP

Tiny library to help you use Firestore with your models.

# TODO

[ ] Adding test
